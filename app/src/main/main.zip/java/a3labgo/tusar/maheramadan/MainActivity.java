package a3labgo.tusar.maheramadan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView[] tv;
    int total_cell=30;
    String roza_no[] = {"১","২","৩","৪","৫","৬","৭","৮","৯","১০"};
    String date;
    String day;
    String sahri;
    String fazar;
    String iftar[] = {"5:35","5:35","5:36","৫:৩৩"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = new TextView[160];
        for(int i=0; i<total_cell; i++) {
            {
                String tvID = "tv" + (i+1);
                int resID = getResources().getIdentifier(tvID, "id", getPackageName());
                tv[i] = ((TextView) findViewById(resID));
            }
        }
        tv[0].setText("Roza no");
        tv[1].setText("Date");
        tv[2].setText("Day");
        tv[3].setText("Sahri");
        tv[4].setText("Fazar");
        tv[5].setText("ইফতার");
        int j=0,k=0,l=0,m=0,n=0,o=0;
        for(int i=6; i<total_cell ; i=i+6){
            tv[i].setText(roza_no[j]);
            j++;
        }
        for(int i=7; i<total_cell ; i=i+6){
            tv[i].setText(date[k]);
            k++;
        }
        for(int i=8; i<total_cell ; i=i+6){
            tv[i].setText(day[l]);
            l++;
        }
        for(int i=9; i<total_cell ; i=i+6){
            tv[i].setText(sahri[m]);
            m++;
        }
        for(int i=10; i<total_cell ; i=i+6){
            tv[i].setText(fazar[n]);
            n++;
        }
        for(int i=11; i<total_cell ; i=i+6){
            tv[i].setText(iftar[o]);
            o++;
        }
    }
}
